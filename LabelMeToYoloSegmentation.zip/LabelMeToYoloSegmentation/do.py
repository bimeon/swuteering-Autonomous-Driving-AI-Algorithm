import os
from Convert import convert

print("Starting conversion process...")

base_dir = 'C:/Windows/System32/2DBB/dataset/'
splits = ['train', 'valid', 'test']
files_converted = 0

for split in splits:
    json_dir = os.path.join(base_dir, split, 'labels')  # 각 split 폴더 안의 labels 폴더 경로
    output_label_dir = json_dir  # YOLO 라벨 파일을 저장할 디렉토리 경로
    print(f"Checking directory: {json_dir}")
    
    if not os.path.exists(json_dir):
        print(f"Directory not found: {json_dir}")
        continue
    
    for json_file in os.listdir(json_dir):
        if json_file.endswith('.json'):
            json_file_path = os.path.join(json_dir, json_file)
            print(f"Found JSON file: {json_file_path}")
            if convert(json_file_path, output_label_dir):
                files_converted += 1
                print(f"Successfully converted {json_file}")
            else:
                print(f"Failed to convert {json_file}")
        else:
            print(f"No JSON files found in {json_dir}")

if files_converted > 0:
    print(f"Conversion complete. {files_converted} files converted.")
else:
    print("No files were converted. Please check for errors.")

print("Process completed.")

