import os
import json

# 클래스 이름을 정의합니다. YOLO 포맷에서 클래스 ID로 사용됩니다.
class_names = ['car', 'bus', 'truck', 'special vehicle', 'motorcycle', 'bicycle', 'personal mobility', 'person', 'Traffic_light', 'Traffic_sign']

def convert(json_file_path, output_label_dir):
    """
    JSON 파일을 YOLO 형식의 텍스트 파일로 변환하는 함수입니다.
    
    :param json_file_path: 변환할 JSON 파일의 경로
    :param output_label_dir: 변환된 YOLO 라벨 파일을 저장할 디렉토리 경로
    :return: 변환이 성공하면 True, 실패하면 False를 반환
    """
    try:
        # JSON 파일을 열고 데이터를 로드합니다.
        with open(json_file_path) as f:
            data = json.load(f)

        # JSON 데이터에서 이미지 크기와 주석 정보를 추출합니다.
        image_width = data['image_size'][0]   # 이미지 너비
        image_height = data['image_size'][1]  # 이미지 높이
        annotations = data['Annotation']      # 이미지에 대한 주석 정보

        yolo_format = []  # YOLO 포맷의 라벨 정보를 저장할 리스트입니다.
        for annotation in annotations:
            class_name = annotation['class_name']  # 주석의 클래스 이름
            if class_name not in class_names:
                # 클래스 이름이 class_names 리스트에 없을 경우 경고를 출력합니다.
                print(f"Warning: Class '{class_name}' not found in class_names")
                continue
            
            class_id = class_names.index(class_name)  # 클래스 이름을 클래스 ID로 변환합니다.
            x_min, y_min, x_max, y_max = annotation['data']  # 객체의 좌표 정보를 추출합니다.

            # YOLO 포맷으로 변환합니다.
            x_center = (x_min + x_max) / 2.0 / image_width  # 객체의 x 중심 좌표 (정규화된 값)
            y_center = (y_min + y_max) / 2.0 / image_height  # 객체의 y 중심 좌표 (정규화된 값)
            width = (x_max - x_min) / image_width  # 객체의 너비 (정규화된 값)
            height = (y_max - y_min) / image_height  # 객체의 높이 (정규화된 값)

            # YOLO 포맷으로 변환된 라벨을 yolo_format 리스트에 추가합니다.
            yolo_format.append(f"{class_id} {x_center} {y_center} {width} {height}")

        # 변환된 YOLO 형식의 라벨을 TXT 파일로 저장합니다.
        output_file_path = os.path.join(output_label_dir, os.path.splitext(os.path.basename(json_file_path))[0] + '.txt')
        with open(output_file_path, 'w') as out_file:
            out_file.write('\n'.join(yolo_format))  # 각 라벨 정보를 줄바꿈으로 구분하여 저장합니다.
        
        return True  # 변환이 성공했음을 반환

    except KeyError as e:
        print(f"Error processing {json_file_path}: missing key {e}")
    except Exception as e:
        print(f"Error processing {json_file_path}: {e}")
    
    return False  # 변환이 실패했음을 반환
